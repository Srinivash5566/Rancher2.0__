import { useNavigate, useLocation } from "react-router-dom";
import { GoArrowLeft } from "react-icons/go";
import { useState } from "react";
import styles from "./stylesheet/component.module.css";

const BuyPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { selectedCrop } = location.state || {};

  const [formData, setFormData] = useState({
    name: "",
    address: "",
    phone: "",
    paymentMethod: "Credit Card",
  });

  if (!selectedCrop) {
    return (
      <div className={styles.buyPageContainer}>
        <header className={styles.buyHeader}>
          <GoArrowLeft
            className={styles.buyBackButton}
            onClick={() => navigate(-1)}
            aria-label="Go back"
            role="button"
            tabIndex={0}
          />
          <h1 className={styles.buyHeaderTitle}>Rancher</h1>
        </header>
        <main className={styles.buyNotFound}>
          <section style={{ textAlign: "center" }}>
            <h2
              style={{
                fontFamily: "'DM Serif Display', serif",
                fontWeight: 400,
                fontSize: "28px",
                marginBottom: "20px",
              }}
            >
              No item selected for purchase 😢
            </h2>
            <button
              onClick={() => navigate("/")}
              style={{
                background: "var(--accent_primary)",
                color: "white",
                padding: "13px 28px",
                borderRadius: "12px",
                border: "none",
                cursor: "pointer",
                fontFamily: "'DM Sans', sans-serif",
                fontWeight: 600,
                fontSize: "15px",
              }}
            >
              Back to Home
            </button>
          </section>
        </main>
      </div>
    );
  }

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Purchase successful!");
    navigate("/");
  };

  return (
    <div className={styles.buyPageContainer}>
      <header className={styles.buyHeader}>
        <GoArrowLeft
          className={styles.buyBackButton}
          onClick={() => navigate(-1)}
          aria-label="Go back"
          role="button"
          tabIndex={0}
        />
        <h1 className={styles.buyHeaderTitle}>Checkout</h1>
      </header>

      <main className={styles.buyCheckoutContainer}>
        {/* Order Summary */}
        <section
          className={styles.buyOrderSummary}
          aria-labelledby="order-summary-title"
        >
          <figure style={{ margin: 0 }}>
            <img
              className={styles.buyOrderImage}
              src={selectedCrop.images[0]}
              alt={`Image of ${selectedCrop.name}`}
              loading="lazy"
            />
          </figure>
          <div className={styles.buyOrderDetails}>
            <h2 id="order-summary-title">{selectedCrop.name}</h2>
            <p>{selectedCrop.category}</p>
            <div
              style={{
                display: "flex",
                alignItems: "baseline",
                gap: "12px",
                marginTop: "8px",
              }}
            >
              <h4>
                ₹
                {(
                  selectedCrop.price *
                  (1 - selectedCrop.discount / 100)
                ).toFixed(2)}
              </h4>
              <span className={styles.buyOriginalPrice}>
                ₹{selectedCrop.price.toFixed(2)}
              </span>
            </div>
          </div>
        </section>

        {/* Checkout Form */}
        <section aria-labelledby="checkout-form-title" style={{ flex: 1.5 }}>
          <h2 id="checkout-form-title" style={{ display: "none" }}>
            Checkout Details
          </h2>
          <form className={styles.buyCheckoutForm} onSubmit={handleSubmit}>
            <fieldset style={{ border: "none", padding: 0, margin: 0 }}>
              <legend style={{ display: "none" }}>
                Delivery & Payment Information
              </legend>

              <label htmlFor="checkout-name">Name</label>
              <input
                id="checkout-name"
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Your full name"
                required
                aria-required="true"
              />

              <label htmlFor="checkout-address">Address</label>
              <textarea
                id="checkout-address"
                name="address"
                value={formData.address}
                onChange={handleChange}
                placeholder="Delivery address"
                required
                aria-required="true"
                rows="3"
                style={{
                  width: "100%",
                  padding: "13px 16px",
                  background: "rgba(0,0,0,0.14)",
                  border: "1px solid var(--border_color)",
                  borderRadius: "12px",
                  color: "var(--main_color)",
                  fontFamily: "'DM Sans', sans-serif",
                  fontSize: "15px",
                  marginBottom: "20px",
                  outline: "none",
                  resize: "vertical",
                  transition: "all 0.25s ease",
                }}
              />

              <label htmlFor="checkout-phone">Phone</label>
              <input
                id="checkout-phone"
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                placeholder="+91 XXXXX XXXXX"
                required
                aria-required="true"
              />

              <label htmlFor="checkout-payment">Payment Method</label>
              <select
                id="checkout-payment"
                name="paymentMethod"
                value={formData.paymentMethod}
                onChange={handleChange}
              >
                <option value="Credit Card">Credit Card</option>
                <option value="Debit Card">Debit Card</option>
                <option value="UPI">UPI</option>
                <option value="Cash on Delivery">Cash on Delivery</option>
              </select>

              <button type="submit" className={styles.buyConfirmButton}>
                Confirm Purchase
              </button>
            </fieldset>
          </form>
        </section>
      </main>
    </div>
  );
};

export default BuyPage;
