import { useNavigate, useParams } from "react-router-dom";
import { GoArrowLeft } from "react-icons/go";
import { useCrop } from "../CropContext";
import { useState } from "react";
import styles from "./stylesheet/component.module.css";

const CardInfo = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { CropData } = useCrop();

  const selectedCrop = CropData.find(
    (crop) => crop.name === decodeURIComponent(id),
  );
  const defaultImages = ["https://picsum.photos/400/400"];
  const images = selectedCrop?.images?.filter(Boolean).length
    ? selectedCrop.images.filter(Boolean)
    : defaultImages;
  const [selectedImage, setSelectedImage] = useState(images[0]);

  if (!selectedCrop) {
    return (
      <div className={styles.pageContainer}>
        <header
          style={{
            display: "flex",
            alignItems: "center",
            marginBottom: "32px",
          }}
        >
          <GoArrowLeft
            className={styles.backButton}
            onClick={() => navigate(-1)}
            aria-label="Go back"
            role="button"
            tabIndex={0}
          />
          <h1 className={styles.headerTitle}>Rancher</h1>
        </header>
        <main className={styles.notFound}>
          <h2
            style={{
              fontFamily: "'DM Serif Display', serif",
              fontWeight: 400,
              fontSize: "28px",
            }}
          >
            Crop not found 😢
          </h2>
          <button
            onClick={() => navigate("/")}
            style={{
              background: "var(--accent_primary)",
              color: "white",
              padding: "13px 28px",
              borderRadius: "12px",
              border: "none",
              cursor: "pointer",
              fontFamily: "'DM Sans', sans-serif",
              fontWeight: 600,
              fontSize: "15px",
            }}
          >
            Back to Home
          </button>
        </main>
      </div>
    );
  }

  return (
    <div className={styles.pageContainer}>
      <header
        style={{ display: "flex", alignItems: "center", marginBottom: "32px" }}
      >
        <GoArrowLeft
          className={styles.backButton}
          onClick={() => navigate(-1)}
          aria-label="Go back"
          role="button"
          tabIndex={0}
        />
        <h1 className={styles.headerTitle}>Rancher</h1>
      </header>

      <main className={styles.productContainer}>
        <section
          className={styles.productImageContainer}
          aria-label="Product Images"
        >
          <figure style={{ margin: 0, width: "100%" }}>
            <img
              className={styles.mainImage}
              src={selectedImage}
              alt={selectedCrop.name}
              loading="lazy"
            />
          </figure>
          {images.length > 1 && (
            <div className={styles.thumbnailContainer} role="tablist">
              {images.map((img, index) => (
                <img
                  key={index}
                  className={`${styles.thumbnail} ${selectedImage === img ? styles.active : ""}`}
                  src={img}
                  alt={`Thumbnail ${index + 1}`}
                  onClick={() => setSelectedImage(img)}
                  role="tab"
                  aria-selected={selectedImage === img}
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") setSelectedImage(img);
                  }}
                />
              ))}
            </div>
          )}
        </section>

        <section
          className={styles.productDetails}
          aria-labelledby="product-title"
        >
          <header>
            <h2 id="product-title" className={styles.productTitle}>
              {selectedCrop.name}
            </h2>
            <p className={styles.category}>{selectedCrop.category}</p>
          </header>

          <article>
            <p className={styles.description}>{selectedCrop.description}</p>
            <p className={styles.description}>
              <strong>Unit:</strong> 1 Kg
            </p>
          </article>

          <div className={styles.priceContainer}>
            <span className={styles.discount}>-{selectedCrop.discount}%</span>
            <span className={styles.price}>
              ₹
              {(selectedCrop.price * (1 - selectedCrop.discount / 100)).toFixed(
                2,
              )}
            </span>
            <span className={styles.originalPrice}>
              ₹{selectedCrop.price.toFixed(2)}
            </span>
          </div>

          <aside className={styles.buyButtons}>
            <button
              className={styles.buyNow}
              onClick={() => navigate("/pay", { state: { selectedCrop } })}
              aria-label={`Buy ${selectedCrop.name} now`}
            >
              Buy Now
            </button>
          </aside>
        </section>
      </main>
    </div>
  );
};

export default CardInfo;
