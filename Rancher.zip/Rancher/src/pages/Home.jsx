import { Link, useNavigate } from "react-router-dom";
import component from "./stylesheet/component.module.css";
import { useState, useMemo } from "react";
import { useAuth } from "../AuthContext";
import { useCrop } from "../CropContext";
import Theme from "../multfun/Theme";

const Home = () => {
  const navigate = useNavigate();
  const { isLoggedIn, logout } = useAuth();
  const { CropData } = useCrop();
  const [search, setSearch] = useState("");

  const filteredCrops = useMemo(() => {
    if (!search) return CropData;
    return CropData.filter((crop) =>
      crop.name.toLowerCase().includes(search.toLowerCase()),
    );
  }, [search, CropData]);

  return (
    <div className="app">
      <div className="headDiv">
        <header className="header">
          <div className="logo">Rancher</div>
          <div className="search-wrapper">
            <input
              type="text"
              placeholder="Search crops..."
              className="search-bar"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              aria-label="Search crops"
            />
          </div>
          <div className="icbtmBox">
            <Theme />
            <nav className="auth-buttons" aria-label="Authentication">
              {isLoggedIn ? (
                <button className="log-out" onClick={logout}>
                  Log Out
                </button>
              ) : (
                <>
                  <button
                    className="sign-in"
                    onClick={() => navigate("/RegisterPage")}
                  >
                    Sign Up
                  </button>
                  <button
                    className="log-in"
                    onClick={() => navigate("/LoginPage")}
                  >
                    Log In
                  </button>
                </>
              )}
            </nav>
          </div>
        </header>

        <nav className={component.nav_bar} aria-label="Main Navigation">
          <Link to="/" className={component.nav_link}>
            RancherAI
          </Link>
          <Link to="/RancherBuySeeds" className={component.nav_link_in}>
            AgriKart
          </Link>
          <Link to="/HarvestingEngines" className={component.nav_link}>
            Harvesting Engines
          </Link>
        </nav>
      </div>

      <main>
        <section className={component.home_grid} aria-label="Available Crops">
          {filteredCrops.map((crop, index) => (
            <article
              key={index}
              className={component.home_card}
              onClick={() => navigate(`/${encodeURIComponent(crop.name)}`)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === "Enter")
                  navigate(`/${encodeURIComponent(crop.name)}`);
              }}
            >
              <figure style={{ margin: 0, overflow: "hidden" }}>
                <img
                  src={
                    crop.images.length > 0
                      ? crop.images[0]
                      : "fallback_image_url"
                  }
                  alt={crop.name}
                  loading="lazy"
                />
              </figure>

              <div className={component.home_card_content}>
                <h3>{crop.name}</h3>
                <div className={component.home_card_price}>
                  <span className={component.disc}>-{crop.discount}%</span>
                  <span className={component.DINR}>
                    ₹{(crop.price * (1 - crop.discount / 100)).toFixed(2)}
                  </span>
                </div>
                <h5>₹{crop.price.toFixed(2)}</h5>
              </div>
            </article>
          ))}
        </section>
      </main>

      <footer />
    </div>
  );
};

export default Home;
