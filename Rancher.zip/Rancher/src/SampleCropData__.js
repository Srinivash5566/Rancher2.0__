export const sampleCrops = [
  {
    name: "Wheat",
    images: [
      "https://www.pexels.com/search/wheat%20seeds/",
      "https://www.pexels.com/search/wheat%20grain/",
      "https://www.pexels.com/search/wheat%20closeup/",
    ],
    price: 2500,
    discount: 10,
  },
  {
    name: "Paddy",
    images: [
      "https://www.pexels.com/search/rice%20seeds/",
      "https://www.pexels.com/search/paddy%20grain/",
      "https://www.pexels.com/search/rice%20closeup/",
    ],
    price: 3200,
    discount: 5,
  },
  {
    name: "Corn",
    images: [
      "https://www.pexels.com/search/corn%20seeds/",
      "https://www.pexels.com/search/maize%20kernels/",
      "https://www.pexels.com/search/corn%20closeup/",
    ],
    price: 2800,
    discount: 12,
  },
  {
    name: "Barley",
    images: [
      "https://www.pexels.com/search/barley%20seeds/",
      "https://www.pexels.com/search/barley%20grain/",
      "https://www.pexels.com/search/barley%20closeup/",
    ],
    price: 2300,
    discount: 8,
  },
  {
    name: "Soybeans",
    images: [
      "https://www.pexels.com/search/soybean%20seeds/",
      "https://www.pexels.com/search/soybeans%20closeup/",
      "https://www.pexels.com/search/soybean%20grain/",
    ],
    price: 3500,
    discount: 15,
  },
  {
    name: "Cotton",
    images: [
      "https://www.pexels.com/search/cotton%20seeds/",
      "https://www.pexels.com/search/cotton%20boll/",
      "https://www.pexels.com/search/cotton%20fiber/",
    ],
    price: 4200,
    discount: 20,
  },
  {
    name: "Sugarcane",
    images: [
      "https://www.pexels.com/search/sugarcane/",
      "https://www.pexels.com/search/sugarcane%20field/",
      "https://www.pexels.com/search/sugarcane%20juice/",
    ],
    price: 3800,
    discount: 10,
  },
  {
    name: "Potato",
    images: [
      "https://www.pexels.com/search/potato%20seeds/",
      "https://www.pexels.com/search/potato%20closeup/",
      "https://www.pexels.com/search/potato%20harvest/",
    ],
    price: 1800,
    discount: 7,
  },
  {
    name: "Tomato",
    images: [
      "https://www.pexels.com/search/tomato%20seeds/",
      "https://www.pexels.com/search/tomato%20closeup/",
      "https://www.pexels.com/search/tomato%20fresh/",
    ],
    price: 1500,
    discount: 5,
  },
  {
    name: "Onion",
    images: [
      "https://www.pexels.com/search/onion%20seeds/",
      "https://www.pexels.com/search/onion%20closeup/",
      "https://www.pexels.com/search/onion%20fresh/",
    ],
    price: 1400,
    discount: 6,
  },
  {
    name: "Carrot",
    images: [
      "https://www.pexels.com/search/carrot%20seeds/",
      "https://www.pexels.com/search/carrot%20closeup/",
      "https://www.pexels.com/search/carrot%20fresh/",
    ],
    price: 1600,
    discount: 9,
  },
  {
    name: "Peas",
    images: [
      "https://www.pexels.com/search/peas%20seeds/",
      "https://www.pexels.com/search/peas%20closeup/",
      "https://www.pexels.com/search/peas%20fresh/",
    ],
    price: 2000,
    discount: 4,
  },
  {
    name: "Lettuce",
    images: [
      "https://www.pexels.com/search/lettuce%20seeds/",
      "https://www.pexels.com/search/lettuce%20closeup/",
      "https://www.pexels.com/search/lettuce%20fresh/",
    ],
    price: 1200,
    discount: 5,
  },
  {
    name: "Cabbage",
    images: [
      "https://www.pexels.com/search/cabbage%20seeds/",
      "https://www.pexels.com/search/cabbage%20closeup/",
      "https://www.pexels.com/search/cabbage%20fresh/",
    ],
    price: 1300,
    discount: 8,
  },
  {
    name: "Spinach",
    images: [
      "https://www.pexels.com/search/spinach%20seeds/",
      "https://www.pexels.com/search/spinach%20closeup/",
      "https://www.pexels.com/search/spinach%20fresh/",
    ],
    price: 1100,
    discount: 10,
  },
  {
    name: "Banana",
    images: [
      "https://www.pexels.com/search/banana/",
      "https://www.pexels.com/search/banana%20plantation/",
      "https://www.pexels.com/search/banana%20fresh/",
    ],
    price: 2200,
    discount: 6,
  },
  {
    name: "Mango",
    images: [
      "https://www.pexels.com/search/mango/",
      "https://www.pexels.com/search/mango%20tree/",
      "https://www.pexels.com/search/mango%20fruit/",
    ],
    price: 5000,
    discount: 15,
  },
  {
    name: "Apple",
    images: [
      "https://www.pexels.com/search/apple/",
      "https://www.pexels.com/search/apple%20orchard/",
      "https://www.pexels.com/search/apple%20fruit/",
    ],
    price: 4500,
    discount: 12,
  },
  {
    name: "Grapes",
    images: [
      "https://www.pexels.com/search/grapes/",
      "https://www.pexels.com/search/vineyard/",
      "https://www.pexels.com/search/grapes%20closeup/",
    ],
    price: 4000,
    discount: 10,
  },
  {
    name: "Orange",
    images: [
      "https://www.pexels.com/search/orange%20fruit/",
      "https://www.pexels.com/search/orange%20tree/",
      "https://www.pexels.com/search/orange%20closeup/",
    ],
    price: 3500,
    discount: 8,
  },
];
